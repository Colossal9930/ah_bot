const Command = require("../../base/Command.js");

class InviteCMD extends Command {
    constructor (client) {
      super(client, {
        name: "invite",
        description: "Sends the invite link of the bot",
        category: "Utility",
        usage: "invite",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
      const e = new MessageEmbed()
        .setTitle('My Invite Link')
        .setDescription(`[Click here](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=2146958591&redirect_uri=http%3A%2F%2Fdiscord.com%2Finvite%2FKkS6yP8&scope=bot&response=code)`)
        .setFooter(message.author.username, message.author.avatarURL())
      message.channel.send(e);
    }
}

module.exports = InviteCMD;