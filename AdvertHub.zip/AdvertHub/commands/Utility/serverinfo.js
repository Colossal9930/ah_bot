const Command = require("../../base/Command.js");
const moment = require('moment');

class ServerInfoCMD extends Command {
    constructor (client) {
      super(client, {
        name: "serverinfo",
        description: "Get information about a server.",
        category: "Utility",
        usage: "serverinfo",
        aliases: ['si'],
        permLevel: "User",
        guildOnly: true,
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        const then = moment(message.guild.createdAt);
        const time = then.from(moment());
        const ca = then.format("MMM Do, YYYY");
        
        const roles = message.guild.roles.cache.sort((a, b) => b.position - a.position);
        let roles1 = roles.array().join(', ');
        if (roles1 === undefined || roles1.length == 0) roles1 = "No Roles";
        if (roles1.length > 1020) {
            roles1 = roles1.substring(0, 1020).replace(/,[^,]+$/, "");
            roles1 = roles1 + " ...";
        }

        let lvl = "";
        if(message.guild.verificationLevel.toProperCase() == "None") lvl = "None";
        if(message.guild.verificationLevel.toProperCase() == "Low") lvl = "Low";
        if(message.guild.verificationLevel.toProperCase() == "Medium") lvl = "Medium";
        if(message.guild.verificationLevel.toProperCase() == "High") lvl = "(╯°□°）╯︵ ┻━┻";
        if(message.guild.verificationLevel.toProperCase() == "Very_high") lvl = "┻━┻彡 ヽ(ಠ益ಠ)ノ彡┻━┻'";

        const embed = new MessageEmbed()
            .setTitle(`${message.guild.name}'s Information`)
            .setColor('#EE82EE')
            .setThumbnail((message.guild.iconURL().includes('.jpg')) ? message.guild.iconURL().replace('.jpg', '.png') : message.guild.iconURL())
            .setFooter(message.author.username, message.author.displayAvatarURL())
            .addField('Name', message.guild.name, true)
            .addField('ID', message.guild.id, true)
            .addField('Owner', message.guild.owner.user.tag, true)
            .addField(`Verification Level`, lvl, true)
            .addField('Channels', message.guild.channels.cache.size.toLocaleString(), true)
            .addField('Created At', `${ca} \n (${time})`, true)
            .addField('Region', message.guild.region, true)
            .addField('AFK Channel', `${(message.guild.afkChannel && message.guild.afkChannel.name) || "Not Set"}`, true)
            .addField(`Members [${message.guild.members.cache.size}]`, `:person_standing: ${message.guild.members.cache.filter(m => !m.user.bot).size} **|** :robot: ${message.guild.members.cache.filter(m => m.user.bot).size}`, true)
            .addField(`Roles (${message.guild.roles.cache.size.toLocaleString()})`, roles1, true);
        message.channel.send(embed);
    }
}

module.exports = ServerInfoCMD;