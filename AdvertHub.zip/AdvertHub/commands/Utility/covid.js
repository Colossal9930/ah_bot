const Command = require("../../base/Command.js");

class COVID19CMD extends Command {
    constructor (client) {
      super(client, {
        name: "covid",
        description: "COVID-19 Stats (includes all cases, all deaths, all recovered, country cases, deaths, recovered and more)",
        category: "Fun",
        usage: "covid <country>",
        aliases: ['corona', 'covidstats', 'covid19'],
        permLevel: "User",
        guildOnly: false,
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
      const fetch = require('node-fetch');
      let country;
      if (args.length == 0) {
        country = 'USA';
      } else {
        country = args.join(' ');
      }
      country = Country(country);
      const api = 'https://corona.lmao.ninja/v2/all';
      const api2 = 'https://corona.lmao.ninja/v2/countries?sort=%7Bparameter%7D';
      const api3 = 'https://corona.lmao.ninja/v2/historical/';
      if (country != null) {
        const res = await fetch(api);
        if (res.status == 200) {
          const json = await res.json();
          const res2 = await fetch(api2);
          const json2 = await res2.json();
          const res3 = await fetch(api3);
          const json3 = await res3.json();
          let object = json2.find(obj => obj.country == country);
          let top = json2.indexOf(object) + 1;
          let cases, deaths, recovered, lastDate;
          if (["Australia","Canada","China","Denmark","France","Netherlands","UK","USA"].includes(country)) {
            cases = 0;
            deaths = 0;
            recovered = 0;
            let temp;
            if (country == "USA") {
              temp = "US";
            } else if (country == "UK") {
              temp = "United Kingdom";
            } else {
              temp = country;
            }
            for (let i = 0; i < json3.length; i++) {
              if (json3[i].country == temp) {
                cases += Object.values(json3[i].timeline.cases).pop()-Object.values(json3[i].timeline.cases).slice(-2,-1);
                deaths += Object.values(json3[i].timeline.deaths).pop()-Object.values(json3[i].timeline.deaths).slice(-2,-1);
                cases += Object.values(json3[i].timeline.recovered).pop()-Object.values(json3[i].timeline.recovered).slice(-2,-1);
                if (typeof lastDate == "undefined") {
                  lastDate = Object.keys(json3[i].timeline.cases).pop();
                }
              }
            }
          } else {
            for (let i = 0; i <json3.length; i++) {
              if (json3[i].country == country) {
                cases = Object.values(json3[i].timeline.cases).pop()-Object.values(json3[i].timeline.cases).slice(-2,-1);
                deaths = Object.values(json3[i].timeline.deaths).pop()-Object.values(json3[i].timeline.deaths).slice(-2,-1);
                recovered = Object.values(json3[i].timeline.recovered).pop()-Object.values(json3[i].timeline.recovered).slice(-2,-1);
                lastDate = Object.keys(json3[i].timeline.cases).pop();
              }
            }
          }
          const embed = new MessageEmbed();
          embed.setTitle("Covid-19 for " + country + " (Rank " + top + ")")
          embed.setDescription("All cases : "+json.cases+"\nAll deaths : "+json.deaths+"\nAll Recovered : "+json.recovered)
          embed.addField("Total Cases",object.cases,true)
          embed.addField("Total Deaths",object.deaths,true)
          embed.addField("Total Recovered",object.recovered,true)
          embed.addField("Today's Cases",cases,true)
          embed.addField("Today's Deaths",deaths,true)
          embed.addField("Today's Recovered",recovered,true)
          embed.setFooter(country + " in "+lastDate)
          embed.setTimestamp(new Date(json.updated))
          embed.setColor('#d64242')
          message.channel.send(embed)
        } else {
          message.channel.send("The API had an error. Try again later. If this issue persists contact the bot owner/admins")
        }
      } else {
        message.channel.send("Unknown country name!");
      }
      
      function Country(name) {
        const names = {"BD":"BANGLADESH","BE":"BELGIUM","BF":"BURKINA FASO","BG":"BULGARIA","BA":"BOSNIA AND HERZEGOVINA","BB":"BARBADOS","WF":"WALLIS AND FUTUNA","BL":"SAINT BARTHELEMY","BM":"BERMUDA","BN":"BRUNEI","BO":"BOLIVIA","BH":"BAHRAIN","BI":"BURUNDI","BJ":"BENIN","BT":"BHUTAN","JM":"JAMAICA","BV":"BOUVET ISLAND","BW":"BOTSWANA","WS":"SAMOA","BQ":"BONAIRE, SAINT EUSTATIUS AND SABA ","BR":"BRAZIL","BS":"BAHAMAS","JE":"JERSEY","BY":"BELARUS","BZ":"BELIZE","RU":"RUSSIA","RW":"RWANDA","RS":"SERBIA","TL":"EAST TIMOR","RE":"REUNION","TM":"TURKMENISTAN","TJ":"TAJIKISTAN","RO":"ROMANIA","TK":"TOKELAU","GW":"GUINEA-BISSAU","GU":"GUAM","GT":"GUATEMALA","GS":"SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS","GR":"GREECE","GQ":"EQUATORIAL GUINEA","GP":"GUADELOUPE","JP":"JAPAN","GY":"GUYANA","GG":"GUERNSEY","GF":"FRENCH GUIANA","GE":"GEORGIA","GD":"GRENADA","GB":"UNITED KINGDOM","GA":"GABON","SV":"EL SALVADOR","GN":"GUINEA","GM":"GAMBIA","GL":"GREENLAND","GI":"GIBRALTAR","GH":"GHANA","OM":"OMAN","TN":"TUNISIA","JO":"JORDAN","HR":"CROATIA","HT":"HAITI","HU":"HUNGARY","HK":"HONG KONG","HN":"HONDURAS","HM":"HEARD ISLAND AND MCDONALD ISLANDS","VE":"VENEZUELA","PR":"PUERTO RICO","PS":"PALESTINIAN TERRITORY","PW":"PALAU","PT":"PORTUGAL","SJ":"SVALBARD AND JAN MAYEN","PY":"PARAGUAY","IQ":"IRAQ","PA":"PANAMA","PF":"FRENCH POLYNESIA","PG":"PAPUA NEW GUINEA","PE":"PERU","PK":"PAKISTAN","PH":"PHILIPPINES","PN":"PITCAIRN","PL":"POLAND","PM":"SAINT PIERRE AND MIQUELON","ZM":"ZAMBIA","EH":"WESTERN SAHARA","EE":"ESTONIA","EG":"EGYPT","ZA":"SOUTH AFRICA","EC":"ECUADOR","IT":"ITALY","VN":"VIETNAM","SB":"SOLOMON ISLANDS","ET":"ETHIOPIA","SO":"SOMALIA","ZW":"ZIMBABWE","SA":"SAUDI ARABIA","ES":"SPAIN","ER":"ERITREA","ME":"MONTENEGRO","MD":"MOLDOVA","MG":"MADAGASCAR","MF":"SAINT MARTIN","MA":"MOROCCO","MC":"MONACO","UZ":"UZBEKISTAN","MM":"MYANMAR","ML":"MALI","MO":"MACAO","MN":"MONGOLIA","MH":"MARSHALL ISLANDS","MK":"MACEDONIA","MU":"MAURITIUS","MT":"MALTA","MW":"MALAWI","MV":"MALDIVES","MQ":"MARTINIQUE","MP":"NORTHERN MARIANA ISLANDS","MS":"MONTSERRAT","MR":"MAURITANIA","IM":"ISLE OF MAN","UG":"UGANDA","TZ":"TANZANIA","MY":"MALAYSIA","MX":"MEXICO","IL":"ISRAEL","FR":"FRANCE","IO":"BRITISH INDIAN OCEAN TERRITORY","SH":"SAINT HELENA","FI":"FINLAND","FJ":"FIJI","FK":"FALKLAND ISLANDS","FM":"MICRONESIA","FO":"FAROE ISLANDS","NI":"NICARAGUA","NL":"NETHERLANDS","NO":"NORWAY","NA":"NAMIBIA","VU":"VANUATU","NC":"NEW CALEDONIA","NE":"NIGER","NF":"NORFOLK ISLAND","NG":"NIGERIA","NZ":"NEW ZEALAND","NP":"NEPAL","NR":"NAURU","NU":"NIUE","CK":"COOK ISLANDS","XK":"KOSOVO","CI":"IVORY COAST","CH":"SWITZERLAND","CO":"COLOMBIA","CN":"CHINA","CM":"CAMEROON","CL":"CHILE","CC":"COCOS ISLANDS","CA":"CANADA","CG":"REPUBLIC OF THE CONGO","CF":"CENTRAL AFRICAN REPUBLIC","CD":"DEMOCRATIC REPUBLIC OF THE CONGO","CZ":"CZECH REPUBLIC","CY":"CYPRUS","CX":"CHRISTMAS ISLAND","CR":"COSTA RICA","CW":"CURACAO","CV":"CAPE VERDE","CU":"CUBA","SZ":"SWAZILAND","SY":"SYRIA","SX":"SINT MAARTEN","KG":"KYRGYZSTAN","KE":"KENYA","SS":"SOUTH SUDAN","SR":"SURINAME","KI":"KIRIBATI","KH":"CAMBODIA","KN":"SAINT KITTS AND NEVIS","KM":"COMOROS","ST":"SAO TOME AND PRINCIPE","SK":"SLOVAKIA","KR":"SOUTH KOREA","SI":"SLOVENIA","KP":"NORTH KOREA","KW":"KUWAIT","SN":"SENEGAL","SM":"SAN MARINO","SL":"SIERRA LEONE","SC":"SEYCHELLES","KZ":"KAZAKHSTAN","KY":"CAYMAN ISLANDS","SG":"SINGAPORE","SE":"SWEDEN","SD":"SUDAN","DO":"DOMINICAN REPUBLIC","DM":"DOMINICA","DJ":"DJIBOUTI","DK":"DENMARK","VG":"BRITISH VIRGIN ISLANDS","DE":"GERMANY","YE":"YEMEN","DZ":"ALGERIA","US":"UNITED STATES","UY":"URUGUAY","YT":"MAYOTTE","UM":"UNITED STATES MINOR OUTLYING ISLANDS","LB":"LEBANON","LC":"SAINT LUCIA","LA":"LAOS","TV":"TUVALU","TW":"TAIWAN","TT":"TRINIDAD AND TOBAGO","TR":"TURKEY","LK":"SRI LANKA","LI":"LIECHTENSTEIN","LV":"LATVIA","TO":"TONGA","LT":"LITHUANIA","LU":"LUXEMBOURG","LR":"LIBERIA","LS":"LESOTHO","TH":"THAILAND","TF":"FRENCH SOUTHERN TERRITORIES","TG":"TOGO","TD":"CHAD","TC":"TURKS AND CAICOS ISLANDS","LY":"LIBYA","VA":"VATICAN","VC":"SAINT VINCENT AND THE GRENADINES","AE":"UNITED ARAB EMIRATES","AD":"ANDORRA","AG":"ANTIGUA AND BARBUDA","AF":"AFGHANISTAN","AI":"ANGUILLA","VI":"U.S. VIRGIN ISLANDS","IS":"ICELAND","IR":"IRAN","AM":"ARMENIA","AL":"ALBANIA","AO":"ANGOLA","AQ":"ANTARCTICA","AS":"AMERICAN SAMOA","AR":"ARGENTINA","AU":"AUSTRALIA","AT":"AUSTRIA","AW":"ARUBA","IN":"INDIA","AX":"ALAND ISLANDS","AZ":"AZERBAIJAN","IE":"IRELAND","ID":"INDONESIA","UA":"UKRAINE","QA":"QATAR","MZ":"MOZAMBIQUE"}
        const iso3 = {"BD": "BGD", "BE": "BEL", "BF": "BFA", "BG": "BGR", "BA": "BIH", "BB": "BRB", "WF": "WLF", "BL": "BLM", "BM": "BMU", "BN": "BRN", "BO": "BOL", "BH": "BHR", "BI": "BDI", "BJ": "BEN", "BT": "BTN", "JM": "JAM", "BV": "BVT", "BW": "BWA", "WS": "WSM", "BQ": "BES", "BR": "BRA", "BS": "BHS", "JE": "JEY", "BY": "BLR", "BZ": "BLZ", "RU": "RUS", "RW": "RWA", "RS": "SRB", "TL": "TLS", "RE": "REU", "TM": "TKM", "TJ": "TJK", "RO": "ROU", "TK": "TKL", "GW": "GNB", "GU": "GUM", "GT": "GTM", "GS": "SGS", "GR": "GRC", "GQ": "GNQ", "GP": "GLP", "JP": "JPN", "GY": "GUY", "GG": "GGY", "GF": "GUF", "GE": "GEO", "GD": "GRD", "GB": "GBR", "GA": "GAB", "SV": "SLV", "GN": "GIN", "GM": "GMB", "GL": "GRL", "GI": "GIB", "GH": "GHA", "OM": "OMN", "TN": "TUN", "JO": "JOR", "HR": "HRV", "HT": "HTI", "HU": "HUN", "HK": "HKG", "HN": "HND", "HM": "HMD", "VE": "VEN", "PR": "PRI", "PS": "PSE", "PW": "PLW", "PT": "PRT", "SJ": "SJM", "PY": "PRY", "IQ": "IRQ", "PA": "PAN", "PF": "PYF", "PG": "PNG", "PE": "PER", "PK": "PAK", "PH": "PHL", "PN": "PCN", "PL": "POL", "PM": "SPM", "ZM": "ZMB", "EH": "ESH", "EE": "EST", "EG": "EGY", "ZA": "ZAF", "EC": "ECU", "IT": "ITA", "VN": "VNM", "SB": "SLB", "ET": "ETH", "SO": "SOM", "ZW": "ZWE", "SA": "SAU", "ES": "ESP", "ER": "ERI", "ME": "MNE", "MD": "MDA", "MG": "MDG", "MF": "MAF", "MA": "MAR", "MC": "MCO", "UZ": "UZB", "MM": "MMR", "ML": "MLI", "MO": "MAC", "MN": "MNG", "MH": "MHL", "MK": "MKD", "MU": "MUS", "MT": "MLT", "MW": "MWI", "MV": "MDV", "MQ": "MTQ", "MP": "MNP", "MS": "MSR", "MR": "MRT", "IM": "IMN", "UG": "UGA", "TZ": "TZA", "MY": "MYS", "MX": "MEX", "IL": "ISR", "FR": "FRA", "IO": "IOT", "SH": "SHN", "FI": "FIN", "FJ": "FJI", "FK": "FLK", "FM": "FSM", "FO": "FRO", "NI": "NIC", "NL": "NLD", "NO": "NOR", "NA": "NAM", "VU": "VUT", "NC": "NCL", "NE": "NER", "NF": "NFK", "NG": "NGA", "NZ": "NZL", "NP": "NPL", "NR": "NRU", "NU": "NIU", "CK": "COK", "XK": "XKX", "CI": "CIV", "CH": "CHE", "CO": "COL", "CN": "CHN", "CM": "CMR", "CL": "CHL", "CC": "CCK", "CA": "CAN", "CG": "COG", "CF": "CAF", "CD": "COD", "CZ": "CZE", "CY": "CYP", "CX": "CXR", "CR": "CRI", "CW": "CUW", "CV": "CPV", "CU": "CUB", "SZ": "SWZ", "SY": "SYR", "SX": "SXM", "KG": "KGZ", "KE": "KEN", "SS": "SSD", "SR": "SUR", "KI": "KIR", "KH": "KHM", "KN": "KNA", "KM": "COM", "ST": "STP", "SK": "SVK", "KR": "KOR", "SI": "SVN", "KP": "PRK", "KW": "KWT", "SN": "SEN", "SM": "SMR", "SL": "SLE", "SC": "SYC", "KZ": "KAZ", "KY": "CYM", "SG": "SGP", "SE": "SWE", "SD": "SDN", "DO": "DOM", "DM": "DMA", "DJ": "DJI", "DK": "DNK", "VG": "VGB", "DE": "DEU", "YE": "YEM", "DZ": "DZA", "US": "USA", "UY": "URY", "YT": "MYT", "UM": "UMI", "LB": "LBN", "LC": "LCA", "LA": "LAO", "TV": "TUV", "TW": "TWN", "TT": "TTO", "TR": "TUR", "LK": "LKA", "LI": "LIE", "LV": "LVA", "TO": "TON", "LT": "LTU", "LU": "LUX", "LR": "LBR", "LS": "LSO", "TH": "THA", "TF": "ATF", "TG": "TGO", "TD": "TCD", "TC": "TCA", "LY": "LBY", "VA": "VAT", "VC": "VCT", "AE": "ARE", "AD": "AND", "AG": "ATG", "AF": "AFG", "AI": "AIA", "VI": "VIR", "IS": "ISL", "IR": "IRN", "AM": "ARM", "AL": "ALB", "AO": "AGO", "AQ": "ATA", "AS": "ASM", "AR": "ARG", "AU": "AUS", "AT": "AUT", "AW": "ABW", "IN": "IND", "AX": "ALA", "AZ": "AZE", "IE": "IRL", "ID": "IDN", "UA": "UKR", "QA": "QAT", "MZ": "MOZ"};
        const countries = {"CN":"China","IT":"Italy","ES":"Spain","DE":"Germany","IR":"Iran","FR":"France","CH":"Switzerland","NL":"Netherlands","BE":"Belgium","AT":"Austria","NO":"Norway","SE":"Sweden","PT":"Portugal","DK":"Denmark","AU":"Australia","CA":"Canada","MY":"Malaysia","BR":"Brazil","JP":"Japan","TR":"Turkey","IL":"Israel","LU":"Luxembourg","IE":"Ireland","PK":"Pakistan","CL":"Chile","FI":"Finland","TH":"Thailand","IS":"Iceland","PL":"Poland","EC":"Ecuador","GR":"Greece","ID":"Indonesia","SA":"Saudi Arabia","QA":"Qatar","SG":"Singapore","RO":"Romania","SI":"Slovenia","PH":"Philippines","RU":"Russia","IN":"India","BH":"Bahrain","EE":"Estonia","PE":"Peru","EG":"Egypt","HK":"Hong Kong","MX":"Mexico","LB":"Lebanon","PA":"Panama","ZA":"South Africa","HR":"Croatia","IQ":"Iraq","AR":"Argentina","CO":"Colombia","AM":"Armenia","RS":"Serbia","KW":"Kuwait","SK":"Slovakia","SM":"San Marino","BG":"Bulgaria","TW":"Taiwan","DZ":"Algeria","LV":"Latvia","UY":"Uruguay","HU":"Hungary","CR":"Costa Rica","DO":"Dominican Republic","MA":"Morocco","VN":"Vietnam","LT":"Lithuania","JO":"Jordan","BA":"Bosnia and Herzegovina","MT":"Malta","AL":"Albania","AD":"Andorra","CY":"Cyprus","BN":"Brunei","LK":"Sri Lanka","MD":"Moldova","BY":"Belarus","BF":"Burkina Faso","TN":"Tunisia","VE":"Venezuela","NZ":"New Zealand","AZ":"Azerbaijan","KZ":"Kazakhstan","GP":"Guadeloupe","SN":"Senegal","OM":"Oman","GE":"Georgia","KH":"Cambodia","TT":"Trinidad and Tobago","UA":"Ukraine","UZ":"Uzbekistan","CM":"Cameroon","MQ":"Martinique","LI":"Liechtenstein","AF":"Afghanistan","BD":"Bangladesh","GU":"Guam","NG":"Nigeria","HN":"Honduras","PR":"Puerto Rico","PY":"Paraguay","CU":"Cuba","GH":"Ghana","MO":"Macao","JM":"Jamaica","BO":"Bolivia","GY":"Guyana","MU":"Mauritius","MC":"Monaco","GF":"French Guiana","GT":"Guatemala","RW":"Rwanda","ME":"Montenegro","TG":"Togo","PF":"French Polynesia","BB":"Barbados","CI":"Ivory Coast","KG":"Kyrgyzstan","MV":"Maldives","TZ":"Tanzania","ET":"Ethiopia","YT":"Mayotte","GI":"Gibraltar","MN":"Mongolia","AW":"Aruba","KE":"Kenya","SC":"Seychelles","GQ":"Equatorial Guinea","VI":"U.S. Virgin Islands","GA":"Gabon","IM":"Isle of Man","MF":"Saint Martin","SR":"Suriname","BS":"Bahamas","NC":"New Caledonia","KY":"Cayman Islands","SV":"El Salvador","LR":"Liberia","MG":"Madagascar","NA":"Namibia","ZM":"Zambia","ZW":"Zimbabwe","SD":"Sudan","NP":"Nepal","AO":"Angola","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","FJ":"Fiji","GL":"Greenland","GN":"Guinea","HT":"Haiti","MR":"Mauritania","NI":"Nicaragua","NE":"Niger","LC":"Saint Lucia","AG":"Antigua and Barbuda","TD":"Chad","DJ":"Djibouti","ER":"Eritrea","GM":"Gambia","MS":"Montserrat","PG":"Papua New Guinea","SX":"Sint Maarten","SO":"Somalia","UG":"Uganda","US":"USA","KR":"S. Korea","GB":"UK","CZ":"Czechia","AE":"UAE","MK":"North Macedonia","PS":"Palestine","RE":"Réunion","CD":"DRC","SZ":"Eswatini","CW":"Curaçao","CV":"Cabo Verde","CG":"Congo","BL":"St. Barth","VA":"Vatican City","VC":"VSt. Vincent Grenadines","TL":"Timor-Leste"};
        let check;
        name = name.toUpperCase();
        if (name.length != 2) {
          check = Object.values(names).indexOf(name)
          if (check == -1) {
            check = Object.values(iso3).indexOf(name);
            if (check == -1) {
              return null;
            } else {
              let data = Object.keys(iso3)[check];
              return countries[data];
            }
          } else {
            let data = Object.keys(names)[check];
            return countries[data];
          }
        } else {
          check = Object.keys(countries).indexOf(name);
          if (check != 1) {
            return Object.values(countries)[check];
          } else {
            return null;
          }
        }
      }
    }
}

module.exports = COVID19CMD;