const Command = require("../../base/Command.js");

class PingCMD extends Command {
  constructor (client) {
    super(client, {
      name: "ping",
      description: "Latency and API response times.",
      category: "Utility",
      usage: "ping",
      aliases: ["pong"],
      guildOnly: false
    });
  }

  async run (client, message, args, level, database, MessageEmbed) { // eslint-disable-line no-unused-vars
    const e1 = new MessageEmbed()
      .setTitle('Pinging...')
      .setImage(`https://discordemoji.com/assets/emoji/loading.gif`)
      .setColor('GREEN')
    const msg = await message.channel.send(e1);
    const e2 = new MessageEmbed()
      .setTitle(':ping_pong: Pong!')
      .setColor('GREEN')
      .setDescription(`Latency is ${msg.createdTimestamp - message.createdTimestamp}ms.\nAPI Latency is ${Math.round(client.ws.ping)}ms`)
      .setFooter(message.author.username, message.author.avatarURL())
    msg.edit(e2);
  }
}

module.exports = PingCMD;
