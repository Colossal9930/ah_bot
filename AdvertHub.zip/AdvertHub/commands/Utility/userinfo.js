const Command = require("../../base/Command.js");
const moment = require('moment');
const permLevels = require('../../base/Level');

class UserInfoCMD extends Command {
    constructor (client) {
      super(client, {
        name: "userinfo",
        description: "Get information about a user.",
        category: "Utility",
        usage: "userinfo <@user|id>",
        aliases: ['ui'],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        let infoMem;
        if (!args || args.length < 1) {
            infoMem = message.member;
        } else {
            infoMem = message.mentions.members.first() || message.guild.members.cache.find(m => m.id === `${args.join(' ')}`) || message.guild.members.cache.find(m => m.displayName.toUpperCase() === `${args.join(' ').toUpperCase()}`) || message.guild.members.cache.find(m => m.user.username.toUpperCase() === `${args.join(' ').toUpperCase()}`) || message.guild.members.cache.find(m => m.user.username.toLowerCase()
                .includes(`${args.join(' ').toLowerCase()}`));
        }

        if (!infoMem) {
            const f_id = args.join(' ').replace('<@', '').replace('>', '');
            try {
                infoMem = await client.users.fetch(f_id);
            } catch (err) {
                infoMem = message.member;
            }
        }
    
        if (message.guild.member(infoMem)) {
          const device = Object.keys(message.author.presence.clientStatus);
          let devices = [];
          device.forEach((d) => devices.push(d.replace('web', '🌍').replace('desktop', '🖥️').replace('mobile', '📱')));
          const ts = moment(infoMem.user.createdAt);
          const ts2 = moment(infoMem.joinedAt);
          const caTime = ts.from(moment());
          const jaTime = ts2.from(moment());
          const ca = ts.format("MMM Do, YYYY");
          const ja = ts2.format("MMM Do, YYYY");
          const roles = infoMem.roles//.sort((a, b) => b.position - a.position);
          let roles1 = roles.cache.array().join(', ');
          if (roles1 === undefined || roles1.length == 0) roles1 = "No Roles";
          const embed = new MessageEmbed()
            .setAuthor(`${infoMem.user.tag} ${devices} [${infoMem.user.id}] `, infoMem.user.avatarURL())
            .setColor('#55b5ff')
            .setThumbnail(infoMem.user.avatarURL())
            .addField('• User Tag', infoMem.user.tag, true)
            .addField('• Nickname', infoMem.displayName, true)
            .addField('• User ID', infoMem.id, true)
            //.addField('• Last Device Used', devices, true)
            .addField(`• Joined At [${jaTime}]`, ja, true)
            .addField(`• Created At [${caTime}]`, ca, true)
            .addField(`• Permission Level [${client.getPerm(infoMem)}]`, permLevels.find(l => l.level === client.getPerm(infoMem)).name, true)
            .addField('• Account Type', infoMem.user.bot ? `:robot:` : `:person_standing:` , true)
            .addField('• Status', infoMem.presence.status === 'dnd' ? 'Do Not Disturb' :
            infoMem.presence.status === 'offline' ? 'Offline' : 
            infoMem.presence.status === 'idle' ? 'Idle' : 
            infoMem.presence.status === 'online' ? 'Online' : 'Unknown', true)
            .addField(`• Roles [${roles.cache.size}]`, roles1, false);
          message.channel.send(embed);
        } else {
          //not guild member
          const ts = moment(infoMem.createdAt);
          const ca = ts.format("MMM Do, YYYY");
          const caTime = ts.from(moment());
          const embed = new MessageEmbed()
            .setTitle(`${infoMem.username}'s Info`)
            .setColor('#55b5ff')
            .setThumbnail(infoMem.avatarURL())
            .setAuthor(message.member.displayName, message.author.avatarURL())
            .addField('• User Tag', infoMem.tag, true)
            .addField('• User ID', infoMem.id, true)
            .addField('• Account Type', infoMem.bot ? `:robot:` : `:person_standing:` , true)
            .addField(`• Account Created [${caTime}]`, ca, true)
            .addField(`• Permission Level [${client.getPerm(infoMem)}]`, permLevels.find(l => l.level === client.getPerm(infoMem)).name, true);
          message.channel.send(embed);
        }
    }
}

module.exports = UserInfoCMD;