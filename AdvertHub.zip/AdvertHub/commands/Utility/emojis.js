const Command = require("../../base/Command.js");

class EmojisCMD extends Command {
    constructor (client) {
      super(client, {
        name: "emojis",
        description: "Shows all the custom emojis in the server.",
        category: "Utility",
        usage: "emojis",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        const e = new MessageEmbed()
            .setTitle(`Custom Emojis`)
            .setColor('ORANGE')
            .setTimestamp();
        if(message.guild.emojis.cache.size > 0){
            e.setDescription(`\`Here is this server's emoji list!\`\n\n${message.guild.emojis.cache.array().toString()}`);
        }else{
            e.setDescription(`This server has no custom emojis`);
        }
        message.channel.send(e);        
    }
}

module.exports = EmojisCMD;