const Command = require("../../base/Command.js");

class SuggestCMD extends Command {
    constructor (client) {
      super(client, {
        name: "suggest",
        description: "Suggest something to add to the bot.",
        category: "Utility",
        usage: "suggest <text>",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        if(args.length < 1){
            message.channel.send(`Thank you so much for attempting to give a suggestion, but you need to say what you want to suggest`)
        }else{
            if (message.guild.members.cache.get(client.user.id).permissions.has('MANAGE_MESSAGES')) message.delete();
            const e = new MessageEmbed()
                .setColor('GREEN')
                .setDescription(`Your suggestion has been sent!`);
            message.channel.send(e).then(m => setTimeout(function(){ m.delete(); }, 10000));
            const e1 = new MessageEmbed()
                .setAuthor(`${message.author.username}'s Suggestion`, message.author.avatarURL())
                .setColor('BLUE')
                .setDescription(`${args.join(' ')}`)
                .setFooter(`👍 Like | 👎 Dislike`)
            client.channels.cache.get('711603331407020043').send(e1).then((m) => m.react('👍').then(m.react('👎')));
        }
    }
}

module.exports = SuggestCMD;