const Command = require("../../base/Command.js");

/*
  The HELP command is used to display every command's name and description
  to the user, so that he may see what commands are available. The help
  command is also filtered by level, so if a user does not have access to
  a command, it is not shown to them. If a command name is given with the
  help command, its extended help is shown.
*/
class Help extends Command {
  constructor (client) {
    super(client, {
      name: "help",
      description: "Displays all the available commands for you.",
      category: "Utility",
      usage: "help [command]",
      aliases: ["h", "?"],
    });
  }

  async run (client, message, args, level, database, MessageEmbed) {
    const cat = args.join(' ');

    const myCommands = message.guild ?
    client.commands.filter(cmd => client.levelCache[cmd.conf.permLevel] <= level) :
    client.commands.filter(cmd => client.levelCache[cmd.conf.permLevel] <= level && cmd.conf.guildOnly !== true);
    const CommandNames = myCommands.keyArray();

    const embed = new MessageEmbed()
      .setColor('AQUA')
      .setFooter(message.author.username, message.author.avatarURL());

    let query = args[0];
    if (query) {
      const commands = [];

      CommandNames.forEach((cmd) => {
        const command = myCommands.get(cmd).help;
        if (command.category.toLowerCase() === cat.toLowerCase()) {
          commands.push(command);
        }
      });

      const output = [];
      commands.forEach((cmd) => {
        output.push(`\`${message.settings.general.prefix}${cmd.name}\` - ${cmd.description}`);
      });

      if (commands.length <= 0) {
        try {
          let command = query;
          if (client.commands.has(command) || client.commands.has(client.aliases.has(command))) {
            command = client.commands.get(command) || client.commands.get(client.aliases.get(command));
            embed.setTitle(`Help » ${command.help.name.toProperCase()}`)
            embed.addField(`Description`, command.help.description || "None");
            embed.addField(`Usage`, command.help.usage || "None");
            embed.addField(`Aliases`, command.conf.aliases.join(', ') || "None");
			      embed.addField(`Permission Level`, command.conf.permLevel || "Error");
            message.channel.send(embed);
          } else {
            embed.setTitle('Something went wrong!')
            embed.setColor('RED')
            embed.setDescription(`It seems **${query}** not a valid category, or a command name`);
            message.channel.send(embed);
          }
        } catch (_) {
          embed.setTitle('Something went wrong!')
          embed.setColor('RED')
          embed.setDescription(`It seems **${query}** not a valid category, or a command name`);
          message.channel.send(embed);
        }
      } else {
        embed.setTitle(`Help » ${query.toProperCase()}`)
        embed.setDescription(`${output.join('\n')}`);
        message.channel.send(embed);
      }
    }

    if (!query) {
      const myCategories = [];

      CommandNames.forEach((cmd) => {
        const category = myCommands.get(cmd).help.category;
        if (!myCategories.includes(category)) {
          myCategories.push(`${category}`);
        }
      });
      embed.setTitle('Help')
        .setDescription(`Please select a category to see its available commands.\nUsage: \`${message.settings.general.prefix}help <category>\``)
        .addField('Categories', myCategories.join('\n'), true)
        .addField('Other Links', `[Bot Developer](http://discord.gg/KkS6yP8)`, true)
      message.channel.send(embed);
    }
  }
}

module.exports = Help;
