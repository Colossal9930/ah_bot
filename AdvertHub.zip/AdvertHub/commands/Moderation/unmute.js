const Command = require("../../base/Command.js");

class UnmuteCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'unmute',
      description: 'Unmute a user, Self explanatory.',
      category: 'Moderation',
      usage: 'unmute <user> <time>',
      aliases: [],
      permLevel: 'Moderator',
      guildOnly: true,
    });
  }

  run(client, message, args, level, database, MessageEmbed) {
    const embed = new MessageEmbed()

    if (!message.guild.members.cache.get(client.user.id).permissions.has('MANAGE_ROLES')) {
      embed.setDescription('I need `MANAGE_ROLES` to do this.').setColor('RED');
      return message.channel.send(embed);
    }

    const muterole = message.guild.roles.cache.find((r) => r.name == "Muted");
    if (!muterole) {
      embed.setDescription('The role `Muted` does\'t exist.').setColor('RED');
      return message.channel.send(embed);
    }

    if (args.length == 0) {
      embed.setDescription('Please mention a user or specify an id.').setColor('RED');
      return message.channel.send(embed);
    }
    
    let mem = message.guild.members.cache.find((m) => m.id === args[0]) || message.guild.members.cache.find((m) => m.id === message.mentions.users.first().id);
    if (!mem) {
      embed.setDescription('That user does not exist.').setColor('RED');
      return message.channel.send(embed);
    }

    if(!mem.manageable){
      embed.setDescription(`I cannot remove the Muted role from ${mem}.`).setColor('RED');
      return message.channel.send(embed);
    }

    if(!mem.roles.cache.has(muterole.id)){
      embed.setDescription(`${mem} is already unmuted.`).setColor('RED');
      return message.channel.send(embed);
    }

    if(mem.roles.cache.has(muterole.id)) mem.roles.remove([muterole.id]).catch(err => console.log(err));
    embed.setDescription(`${mem} has been unmuted.`).setColor('GREEN');
    message.channel.send(embed);
  }
}

module.exports = UnmuteCommand;
