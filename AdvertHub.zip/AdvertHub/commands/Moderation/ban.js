const Command = require("../../base/Command.js");
const moment = require('moment');
const Hashids = require("hashids/cjs");

class BanCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'ban',
      description: 'Bans a user, Self explanatory.',
      category: 'Moderation',
      usage: 'ban <user> <reason>',
      aliases: [],
      permLevel: 'Moderator',
      guildOnly: true,
    });
  }

  run(client, message, args, level, database, MessageEmbed) {
    let mem; // The selected user (Defined later)
    const embed = new MessageEmbed()

    if (!message.guild.members.cache.get(client.user.id).permissions.has('BAN_MEMBERS')) {
      embed.setDescription('I need `BAN_MEMBERS` to do this.').setColor('RED');
      return message.channel.send(embed);
    }

    if(args.length == 0) {
      embed.setDescription('Please mention a user or specify an id.').setColor('RED');
      return message.channel.send(embed);
    }
    
    mem = message.guild.members.cache.find((m) => m.id === args[0]) || message.guild.members.cache.find((m) => m.id === message.mentions.users.first().id);
    if (!mem) {
      embed.setDescription('That user does not exist.').setColor('RED');
      return message.channel.send(embed);
    }
    let reason = args.join(' ').replace(args[0], '').trim() || "Unspecified Reason";

    if(!mem.bannable){
      embed.setDescription(`I cannot ban ${mem}.`).setColor('RED');
      return message.channel.send(embed);
    }

    if(client.getPerm(mem) >= client.getPerm(message.member)) {
      embed.setDescription('You cannot ban a member at or above your level.').setColor('RED');
      return message.channel.send(embed)
    }

    const banembed = new MessageEmbed().setDescription(`You were banned from **${message.guild.name}** for \`${reason}\``).setColor('RED')
    mem.send(banembed);
    mem.ban(`${reason} | By: ${message.author.tag}`);
    embed.setDescription(`Banned ${mem} for \`${reason}\``).setColor('GREEN');
    message.channel.send(embed);
  }
}

module.exports = BanCommand;
