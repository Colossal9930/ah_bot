const Command = require("../../base/Command.js");

class TemplateCMD extends Command {
    constructor (client) {
      super(client, {
        name: "purge",
        description: "Delete a lot of messages.",
        category: "Moderation",
        usage: "purge <1-100>",
        aliases: [],
        permLevel: "Moderator",
        guildOnly: true,
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        if(!message.guild.members.cache.get(client.user.id).permissions.has('MANAGE_MESSAGES')) return message.channel.send(`I need the permission \`MANAGE_MESSAGES\` to execute this command.`);
        if(isNaN(args[0])) return message.channel.send(`Please supply a valid amount of messages to purge`);
        if(args[0] > 100) return message.channel.send(`Please supply a number less than 100`);
        message.delete();
        message.channel.bulkDelete(args[0]).then(messages => message.channel.send(`Successfully deleted \`${messages.size}/${args[0]}\` messages`))
        .then(msg => msg.delete({ timeout: 1000 })).catch(error => message.channel.send(`**Error: ${error.message}`));
    }
}

module.exports = TemplateCMD;