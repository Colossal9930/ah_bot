const Command = require("../../base/Command.js");
const moment = require('moment');
const Hashids = require("hashids/cjs");

class MuteCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'mute',
      description: 'Mute a user, Self explanatory.',
      category: 'Moderation',
      usage: 'mute <user> <time> <reason>',
      aliases: [],
      permLevel: 'Moderator',
      guildOnly: true,
    });
  }

  run(client, message, args, level, database, MessageEmbed) {
    const embed = new MessageEmbed()

    if (!message.guild.members.cache.get(client.user.id).permissions.has('MANAGE_ROLES')) {
      embed.setDescription('I need `MANAGE_ROLES` to do this.').setColor('RED');
      return message.channel.send(embed);
    }

    const muterole = message.guild.roles.cache.find((r) => r.name == "Muted");
    if (!muterole) {
      embed.setDescription('The role `Muted` does\'t exist.').setColor('RED');
      return message.channel.send(embed);
    }

    if(args.length == 0 || message.mentions.users.size == 0) {
      embed.setDescription('Please mention a user or specify an id.').setColor('RED');
      return message.channel.send(embed);
    }
    
    let mem = message.guild.members.cache.find((m) => m.id === args[0]) || message.guild.members.cache.find((m) => m.id === message.mentions.users.first().id);
    if (!mem) {
      embed.setDescription('That user does not exist.').setColor('RED');
      return message.channel.send(embed);
    }

    if(!mem.manageable){
      embed.setDescription(`Make sure I am above the user you're trying to mute.`).setColor('RED');
      return message.channel.send(embed);
    }
    
    if(client.getPerm(mem) >= client.getPerm(message.member)) {
      embed.setDescription('You cannot mute a user at or above your (bot) level.').setColor('RED');
      return message.channel.send(embed)
    }

    if(mem.roles.cache.has(muterole.id)) {
      embed.setDescription(`That user is already muted.`).setColor('RED');
      return message.channel.send(embed);
    }

    let time = args[1];
    let error = false;
    if(!time) return message.reply('You need to supply a time frame.');
    const takes = time.includes('m') ? moment.duration(parseInt(time.replace('m', '')), "minutes").format('S') : time.includes('h') ? moment.duration(parseInt(time.replace('h', '')), "hours").format('S') : time.includes('d') ? moment.duration(parseInt(time.replace('d', '')), "days").format('S') : error = true;
    if(error == true) return message.reply(`You may only use the formats \`m/h/d\` for the mute time and please make sure the format is sticking to the number!`);
    const timeCheck = moment.duration(parseInt(takes.replace(/,/g, '')), "milliseconds").format('D') <= 3;
    if(timeCheck == false) return message.reply(`You may not mute someone for longer than 3 days!`);
    let durationMute = moment.duration(parseInt(takes.replace(/,/g, '')), "milliseconds").format(" D [days], H [hrs], m [mins], s [secs]");
    
    function generateHash(data1, data2){
      return new Hashids(data1 + data2 + new Date().toString(), 3).encode(1,3,7);
    }

    if(!mem.roles.cache.has(muterole.id)) mem.roles.add([muterole.id]).catch(err => console.log(err));

    embed.setDescription(`Muted ${mem} for \`${durationMute}\``).setColor('GREEN');
    message.channel.send(embed).catch(err => console.log(err));

    setTimeout(async () => {
      if(mem.roles.cache.has(muterole.id)) mem.roles.remove([muterole.id]).catch(err => console.log(err));
    }, parseInt(takes.replace(/,/g, '')))
  }
}

module.exports = MuteCommand;
