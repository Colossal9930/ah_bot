const Command = require("../../base/Command.js");
const moment = require('moment');
const Hashids = require("hashids/cjs");

class KickCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'kick',
      description: 'Kicks a user, Self explanatory.',
      category: 'Moderation',
      usage: 'kick <user> <reason>',
      aliases: [],
      permLevel: 'Moderator',
      guildOnly: true,
    });
  }

  run(client, message, args, level, database, MessageEmbed) { // eslint-disable-line no-unused-vars
    let mem; // The selected user (Defined later)
    const embed = new MessageEmbed()

    if (!message.guild.members.cache.get(client.user.id).permissions.has('KICK_MEMBERS')) {
      embed.setDescription('I need `KICK_MEMBERS` to do this.').setColor('RED');
      return message.channel.send(embed);
    }

    if(args.length == 0) {
      embed.setDescription('Please mention a user or specify an id.').setColor('RED');
      return message.channel.send(embed);
    }
    
    mem = message.guild.members.cache.find((m) => m.id === args[0]) || message.guild.members.cache.find((m) => m.id === message.mentions.users.first().id);
    if (!mem) {
      embed.setDescription('That user does not exist.').setColor('RED');
      return message.channel.send(embed);
    }
    let reason = args.join(' ').replace(args[0], '').trim() || "Unspecified Reason";

    if(!mem.kickable){
      embed.setDescription('That user cannot be kicked.').setColor('RED');
      return message.channel.send(embed);
    }

    const kickembed = new MessageEmbed().setDescription(`You were kicked from **${message.guild.name}** for \`${reason}\``).setColor('RED')
    mem.send(kickembed);
    
    mem.kick(`${reason} | By: ${message.author.tag}`)
    
    embed.setDescription(`Kicked ${mem} for \`${reason}\``).setColor('GREEN');
    message.channel.send(embed);
  }
}
 // Issued: `${moment().format('MM/DD/YYYY')} (MM/DD/YYYY)`,
module.exports = KickCommand;
