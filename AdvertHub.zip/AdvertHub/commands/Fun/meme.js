const Command = require("../../base/Command.js");
const randomPuppy = require('random-puppy');

const subreddits = [
    'dankmemes',
    'memes',
    'me_irl'
];

class MemeCMD extends Command {
    constructor (client) {
      super(client, {
        name: "meme",
        description: "Generates a random meme.",
        category: "Fun",
        usage: "meme",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        const sub = subreddits[Math.round(Math.random() * (subreddits.length - 1))];
    
        randomPuppy(sub).then(url => {
            const embed = new MessageEmbed()
                .setDescription(`r/${sub}`)
                .setImage(url)
                .setColor('RANDOM')
                .setFooter(`Requested by: ${message.author.tag}`);
            message.channel.send(embed)
        });
    }
}

module.exports = MemeCMD;