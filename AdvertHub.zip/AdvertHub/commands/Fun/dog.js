const Command = require("../../base/Command.js");
const { get } = require("snekfetch");

class TemplateCMD extends Command {
    constructor (client) {
      super(client, {
        name: "dog",
        description: "Generate a dog picture.",
        category: "Fun",
        usage: "dog",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        get('http://dog.ceo/api/breeds/image/random').then(r => {
            const e = new MessageEmbed()
                .setColor('RANDOM')
                .setAuthor(message.author.username, message.author.avatarURL)
                .setImage(`${r.body.message}`)
            message.channel.send(e);
        });
    }
}

module.exports = TemplateCMD;