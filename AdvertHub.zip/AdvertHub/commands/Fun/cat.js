const Command = require("../../base/Command.js");
const { get } = require("snekfetch");

class TemplateCMD extends Command {
    constructor (client) {
      super(client, {
        name: "cat",
        description: "Generate a cat picture.",
        category: "Fun",
        usage: "cat",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        get('http://aws.random.cat/meow').then(r => {
            const e = new MessageEmbed()
                .setColor('RANDOM')
                .setAuthor(message.author.username, message.author.avatarURL)
                .setImage(`${r.body.file}`)
            message.channel.send(e);
        });
    }
}

module.exports = TemplateCMD;