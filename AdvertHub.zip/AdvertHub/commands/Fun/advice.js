const Command = require("../../base/Command.js");
const { get } = require("snekfetch");

class AdviceCMD extends Command {
    constructor (client) {
      super(client, {
        name: "advice",
        description: "Generate some random advice.",
        category: "Fun",
        usage: "advice",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        getAdvice(message)
        function getAdvice(message){
            get('http://api.adviceslip.com/advice').then(r => {
                const e = new MessageEmbed()
                    .setColor('RANDOM')
                    .setDescription(`${r.body.slip.advice || "API Error. Try Again"}`)
                message.channel.send(e);
            });
        }
    }
}

module.exports = AdviceCMD;