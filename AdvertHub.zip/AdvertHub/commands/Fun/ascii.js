const Command = require("../../base/Command.js");
const request = require("request");

class AsciiCMD extends Command {
    constructor (client) {
      super(client, {
        name: "ascii",
        description: "Write some ascii text. Works better on PC and short phrases.",
        category: "Fun",
        usage: "ascii <text>",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        if(args.length < 1) return message.channel.send(`Usage ${message.guild.prefix}ascii <text>`)
        request("https://artii.herokuapp.com/make?text=" + args.join(' '), function(error, response, body) {
            if (!error && response.statusCode == 200) {
                var ascii = body;
                message.channel.send("\n```" + ascii + "```");
            }
        });
    }
}

module.exports = AsciiCMD;