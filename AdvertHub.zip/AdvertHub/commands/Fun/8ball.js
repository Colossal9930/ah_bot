const Command = require("../../base/Command.js");
const snekfetch = require("snekfetch");

class MagicballCMD extends Command {
  constructor (client) {
    super(client, {
      name: "8ball",
      description: "Ask the 8ball a question.",
      category: "Fun",
      usage: "8ball <question>",
      guildOnly: true,
      aliases: [],
      permLevel: "User"
    });
  }

  async run (client, message, args, level, database, MessageEmbed) {
    if(args.length < 1) return message.reply('Please specify a question.');
    snekfetch.get('https://8ball.delegator.com/magic/JSON/'+args.join(' ')).then(r => {
        const e = new MessageEmbed()
            .setColor('RANDOM')
            .setAuthor(message.author.username, message.author.avatarURL())
            .addField('Question', args.join(' '))
            .addField('Answer', r.body.magic.answer);
        message.channel.send(e);
    });
  }
}

module.exports = MagicballCMD;
