const Command = require("../../base/Command.js");
const { get } = require("snekfetch");

class JokeCMD extends Command {
    constructor (client) {
      super(client, {
        name: "joke",
        description: "Generate a random joke.",
        category: "Fun",
        usage: "joke",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
        get('https://official-joke-api.appspot.com/random_joke').then(r => {
            const e = new MessageEmbed()
                .setColor('RANDOM')
                .setAuthor(message.author.username, message.author.avatarURL)
                .setDescription(`${r.body.setup} \n\n ${r.body.punchline}`)
            message.channel.send(e);
        });
    }
}

module.exports = JokeCMD;