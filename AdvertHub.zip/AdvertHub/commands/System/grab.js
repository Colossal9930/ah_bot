const Command = require("../../base/Command.js");
const fs = require('fs');

class TemplateCMD extends Command {
    constructor (client) {
      super(client, {
        name: "grab",
        description: "",
        category: "System",
        usage: "grab <commandName>",
        aliases: [],
        permLevel: "User"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
      let em = new MessageEmbed();
      if (!args || args.length < 1) return message.reply('Command is disabled!');

      const commands = client.commands.get(args[0]) || client.commands.get(client.aliases.get(args[0]));
      if(!commands) return message.channel.send(`'${name}' does not exist!`);
      fs.readFile(`${commands.conf.location}/${commands.conf.fileName}`, 'utf8', function (err,data) {
        if (err) return console.log(err);
        const file = Buffer.from(data);
        message.channel.send({ files: [{ name: commands.conf.fileName, attachment: file }]});
      });
    }
}

module.exports = TemplateCMD;