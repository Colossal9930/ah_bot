const Command = require("../../base/Command.js");

class Reboot extends Command {
  constructor (client) {
    super(client, {
      name: "reboot",
      description: "If running under PM2, bot will restart.",
      category: "System",
      usage: "reboot",
      permLevel: "Bot Owner",
      aliases: [],
      guildOnly: true,
    });
  }

  async run (client, message, args, level, database, MessageEmbed) { // eslint-disable-line no-unused-vars
    try {
      const em = new MessageEmbed().setColor('RED').setDescription("Bot is rebooting...");
      await message.channel.send(em).then(m => client.rebootmap.set('ID', m.id).set('ChanID', m.channel.id).set('wasRebooted', true));
      process.exit(1);
    } catch (e) {
      console.log(e);
    }
  }
}

module.exports = Reboot;
