const Command = require("../../base/Command.js");
const { isBoolean } = require('../../modules/Utils.js')

class ConfigCMD extends Command {
    constructor (client) {
      super(client, {
        name: "config",
        description: "View or change settings for your server.",
        category: "System",
        usage: "config <key> <value>",
        guildOnly: true,
        aliases: ['conf', 'settings', 'setting', 'set'],
        permLevel: "Administrator"
      });
    }

    async run (client, message, args, level, database, MessageEmbed) {
      const keys = [
        'prefix', 'modrole', 'adminrole', 
        'leavetoggle', 'leavecolor', 'leaveid', 'leavemsg',
        'antilinks', 'antispam', 'levelsystem',
        'welcometoggle', 'welcomecolor', 'welcomeid', 'welcomemsg',
        'logstoggle', 'logsid'
      ];
      const gSettings = client.database.fn.settings.get(message.guild.id);
      const value = args.slice(1).join(' ');
      const key = args[0];
  
      if (key) {
        if (!keys.includes(key.toLowerCase())) {
          return createEmbed(gSettings, 'RED', `__**That key is not valid or is not editable**__ \nPlease have a look below to see the valid keys also the example is fool proof probably.\nExample: \`${gSettings.general.prefix}config prefix !\``, true);
        } else {
          if(!value) return createEmbed(gSettings, 'RED', `Please define a new value for \`${key}\`.`, false);
          if(key.endsWith('id') && isNaN(value)) return createEmbed(gSettings, 'RED', `The key \`${key}\` is number field only.`, false);
          client.database.fn.settings.update(message.guild.id, {key, value: isBoolean(value)});
          //return createEmbed(client.database.fn.settings.get(message.guild.id), 'GREEN', `Successfully changed ${key} to \`${value}\``, false);
          let oldvalue = 'undefined'
          for (const i in gSettings) {
            if (key in gSettings[i]) {
              oldvalue = gSettings[i][key]
            }
          }

          const cembed = new MessageEmbed()
            .setAuthor(`${message.guild.name}'s Settings`, message.guild.iconURL())
            .setFooter(message.author.username, message.author.avatarURL())
            .setColor('GREEN')
            .setDescription(`Successfully changed \`${key}\``)
            .addField('Old Value', oldvalue, true)
            .addField('New Value', value, true);
          return message.channel.send(cembed);
        }
      } else {
        return createEmbed(gSettings, 'ORANGE', `To set a option below please input a key and a value\nExample: \`${gSettings.general.prefix}config prefix !\``, true);
      }
  
      function createEmbed(settings, color, description, showsettings) {
        const embed = new MessageEmbed()
          .setAuthor(`${message.guild.name}'s Settings`, message.guild.iconURL())
          .setFooter(message.author.username, message.author.avatarURL())
          .setColor(color)
          .setDescription(description);
        if(showsettings === true){
          for (const i in settings) {
            let array = [];
            for (const prop in settings[i]) {
              array.push(`${prop}: ${settings[i][prop]}`);
            }
            embed.addField(i, array.join('\n'));
          }
        }
  
        message.channel.send(embed);
      }
    }
}

module.exports = ConfigCMD;