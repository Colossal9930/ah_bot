/* eslint-disable max-len */
'use strict';
const config = require('../config.js');

/**
 * PERMISSION LEVELS
 *
 * Permission levels need to be reworked but this is the basics of them
 ** 0  =  non-roled users
 ** 1  =  Blank
 ** 2  =  Moderator
 ** 3  =  Administrator
 ** 4  =  Server Owner
 ** 5  =  Blank
 ** 6  =  Blank
 ** 7  =  Blank
 ** 8  =  Bot Support
 ** 9  =  Bot Admin
 ** 10 =  Bot Owner
 */
const permLevels = [
  // Level 0 ~ Everyone has access
  {
    level: 0,
    name: 'User',
    check: () => true,
    checkMember: () => true,
  },
  // Level 2 ~ Moderator or higher has access
  {
    level: 2,
    name: 'Moderator',
    check: (message) => {
      const role = message.client.database.fn.settings.get(message.guild.id).general.modrole;
      if (!role) return false;
      try {
        const modRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === message.client.database.fn.settings.get(message.guild.id).general.modrole.toLowerCase());
        return modRole && message.member.roles.cache.has(modRole.id);
      } catch (e) {
        return false;
      }
    },
    checkMember: (member) => {
      const role = member.client.database.fn.settings.get(member.guild.id).general.modrole;
      if (!role) return false;
      try {
        const modRole = member.guild.roles.cache.find(r => r.name.toLowerCase() === member.client.database.fn.settings.get(member.guild.id).general.modrole.toLowerCase());
        return modRole && member.roles.cache.has(modRole.id);
      } catch (e) {
        return false;
      }
    },
  },
  // Level 3 ~ Admin or higher has access
  {
    level: 3,
    name: 'Administrator',
    check: (message) => {
      const role = message.client.database.fn.settings.get(message.guild.id).general.adminrole;
      if (!role) return false;
      try {
        const adminRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === message.client.database.fn.settings.get(message.guild.id).general.adminrole.toLowerCase());
        return message.member.permissions.has(8) || (adminRole && message.member.roles.cache.has(adminRole.id));
      } catch (e) {
        return false;
      }
    },
    checkMember: (member) => {
      const role = member.client.database.fn.settings.get(member.guild.id).general.adminrole;
      if (!role) return false;
      try {
        const adminRole = member.guild.roles.cache.find(r => r.name.toLowerCase() === member.client.database.fn.settings.get(member.guild.id).general.adminrole.toLowerCase());
        return member.permissions.has(8) || (adminRole && member.roles.cache.has(adminRole.id));
      } catch (e) {
        return false;
      }
    },
  },
  // Level 4 ~ Guild Owner or higher has access
  {
    level: 4,
    name: 'Server Owner',
    check: (message) => {
      if (message.channel.type === 'text') {
        if (message.guild.owner.user.id === message.author.id) return true;
        return false;
      }
      return false;
    },
    checkMember: (member) => {
      if (member.guild.owner.user.id === member.id) return true;
      return false;
    },
  },
  // Level 8 ~ Bot Support or higher has access
  {
    level: 8,
    name: 'Bot Support',
    check: (message) => config.support.includes(message.author.id),
    checkMember: (member) => config.support.includes(member.id),
  },
  // Level 9 ~ Bot Admin or higher has access
  {
    level: 9,
    name: 'Bot Admin',
    check: (message) => config.admins.includes(message.author.id),
    checkMember: (member) => config.admins.includes(member.id),
  },
  // Level 10 ~ Bot owner has access
  {
    level: 10,
    name: 'Bot Owner',
    check: (message) => config.owner === message.author.id,
    checkMember: (member) => config.owner === member.id,
  },
];

module.exports = permLevels;
