const config = {
  // Bot Owner, level 10 by default. You no longer need to supply the owner ID, as the bot
  // will pull this information directly from it's application page.
  "owner": '676782250435543061',

  // Bot Admins, level 9 by default. Array of user ID strings.
  "admins": ['209796601357533184'],

  // Bot Support, level 8 by default. Array of user ID strings
  "support": [],

  // Your Bot's Token. Available at https://discordapp.com/developers/applications/me
  "token":  "PLACE_TOKEN_HERE",
};

module.exports = config;