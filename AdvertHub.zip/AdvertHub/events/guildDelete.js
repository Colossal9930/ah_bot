// This event executes when a new guild (server) is left.
const { MessageEmbed } = require('discord.js')
const Event = require('../base/Event');

module.exports = class extends Event {
  constructor (client) {
    super(client, {
      name: 'guildDelete',
      enabled: true,
    });
  }

  async run (client, guild) {
    if(!guild.available) return;
    client.logger.log(`[GUILD LEAVE] ${guild.name} (${guild.id}) removed the bot.`);
  }
};
