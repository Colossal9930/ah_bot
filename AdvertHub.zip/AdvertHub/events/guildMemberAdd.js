const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'guildMemberAdd',
        enabled: true,
      });
    }
  
    async run (client, member) {
        // Load the guild's settings
        const settings = client.database.fn.settings.get(member.guild.id);

        // If welcome is off, don't proceed (don't welcome the user)
        if (settings.welcome.welcometoggle == true) {
            // Replace the placeholders in the welcome message with actual data
            const welcomeMessage = settings.welcome.welcomemsg.replace("{{user}}", member.user.username).replace("{{tag}}", member).replace("{{guild}}", member.guild.name);

            // Send the welcome message to the welcome channel
            const e = new MessageEmbed()
                .setTitle('Welcome')
                .setDescription(welcomeMessage)
                .setThumbnail(member.user.avatarURL())
                .setFooter(`${member.user.tag} (${member.user.id})`)
                .setColor(settings.welcome.welcomecolor.toUpperCase())
                .setTimestamp();
            member.guild.channels.cache.find(c => c.id === settings.welcome.welcomeid).send(e);
        }
    }
}