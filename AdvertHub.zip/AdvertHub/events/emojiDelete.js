const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'emojiDelete',
        enabled: true,
      });
    }
  
    async run (client, emoji) {
      let database = client.database.fn.settings.get(emoji.guild.id);
      if(database) database = client.database.fn.settings.get(emoji.guild.id).logs;
      let embed = new MessageEmbed();

      if (database.logstoggle) {
        embed.setTitle('Emoji Deleted');
        embed.setColor('RED');
        embed.setThumbnail(emoji.url);
        embed.addField('Name', emoji.name, true);
        embed.addField('Identifier', emoji.identifier, true);
        embed.setFooter(`ID: ${emoji.id}`);
        embed.setTimestamp();
        if(!isNaN(database.logsid) && emoji.guild.channels.cache.find(c => c.id == database.logsid)) emoji.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
      }
    }
}