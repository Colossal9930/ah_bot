const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'guildMemberRemove',
        enabled: true,
      });
    }
  
    async run (client, member) {
        // Load the guild's settings
        const settings = client.database.fn.settings.get(member.guild.id);

        // If leave is off, don't proceed (don't leave the user)
        if (settings.leave.leavetoggle == true) {
            // Replace the placeholders in the welcome message with actual data
            const leaveMessage = settings.leave.leavemsg.replace("{{user}}", member.user.username).replace("{{tag}}", member).replace("{{guild}}", member.guild.name);

            // Send the leave message to the leave channel
            const e = new MessageEmbed()
                .setTitle('Goodbye')
                .setDescription(leaveMessage)
                .setThumbnail(member.user.avatarURL())
                .setFooter(`${member.user.tag} (${member.user.id})`)
                .setColor(settings.leave.leavecolor.toUpperCase())
                .setTimestamp();
            member.guild.channels.cache.find(c => c.id === settings.leave.leaveid).send(e);
            // client.channels.cache.find(c => c.id === settings.leave.leaveid).send(e).catch(console.error);
        }
    }
}