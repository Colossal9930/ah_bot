const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event.js');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'messageUpdate',
        enabled: true,
      })
    }
  
    async run (client, oldMessage, newMessage) {
      // Cancel if nothing changed. (Text not changing? Accidential fire?)
      if(oldMessage == newMessage || oldMessage.content == newMessage.content) return;

      client.emit('message', newMessage);

      if(oldMessage.channel.type == "dm") return;
      // Define database and embed var.
      const database = client.database.fn.settings.get(oldMessage.guild.id);
      let embed = new MessageEmbed();

      if (database.logs.logstoggle) {
        if (oldMessage.author.bot == false) {
          embed.setTitle('Message Edited');
          embed.setURL(newMessage.url);
          embed.setAuthor(oldMessage.author.tag, oldMessage.author.displayAvatarURL);
          embed.setColor('#EE82EE');
          embed.setThumbnail(oldMessage.author.displayAvatarURL);
          embed.addField('Original Message', (oldMessage.content.length <= 1024) ? oldMessage.content : `${oldMessage.content.substring(0, 1020)}...`, true);
          embed.addField('Edited Message', (newMessage.content.length <= 1024) ? newMessage.content : `${newMessage.content.substring(0, 1020)}...`, true);
          embed.addField('Channel', oldMessage.channel, true);
          embed.addField('Message Author', `${oldMessage.author} (${oldMessage.author.tag})`, true);
          embed.addField('Number of Edits', newMessage.edits.length, true);
          (newMessage.mentions.users.size === 0) ? embed.addField('Mentioned Users [0]:', 'None', true): embed.addField(`Mentioned Users [${newMessage.mentions.users.array().length}]:`, newMessage.mentions.users.array(), true);
          embed.setTimestamp();
          if(!isNaN(database.logs.logsid) && oldMessage.guild.channels.cache.find(c => c.id == database.logs.logsid)) oldMessage.guild.channels.cache.find(c => c.id == database.logs.logsid).send(embed);
        }
      }
    }
}
