const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'channelDelete',
        enabled: true,
      });
    }
  
    async run (client, channel) {
      if(channel.type == "dm") return;
      let database = client.database.fn.settings.get(channel.guild.id).logs;
      let embed = new MessageEmbed();
      embed.setTimestamp();
      embed.setColor('RED');
      embed.setFooter(`ID: ${channel.id}`);
      embed.addField('Name', channel.name, true);
      
      if (database.logstoggle) {
        if(channel.type == "voice") {
          embed.setTitle('Voice Channel Deleted');
          embed.addField('Category', (channel.parent && channel.parent.name) ? channel.parent.name : "None", true);
        }else if(channel.type == "text"){
          embed.setTitle('Text Channel Deleted');
          embed.addField('Category', (channel.parent && channel.parent.anem) ? channel.parent.name : "None", true);
        }else if(channel.type == "category"){
          embed.setTitle('Category Deleted');
        }
        if(!isNaN(database.logsid) && channel.guild.channels.cache.find(c => c.id == database.logsid)) channel.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
      }
    }
}