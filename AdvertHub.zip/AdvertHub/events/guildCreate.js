// This event executes when a new guild (server) is joined.
const { MessageEmbed } = require('discord.js');
const moment = require('moment');
const Event = require('../base/Event');

module.exports = class extends Event {
  constructor (client) {
    super(client, {
      name: 'guildCreate',
      enabled: true,
    });
  }

  async run (client, guild) {
    // Copy default settings
    client.database.fn.settings.copyDefaults(guild.id);

    // Log guild join
    const e = new MessageEmbed()
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL())
      .setColor('GREEN')
      .addField('Owner', `${guild.owner.user.tag} \`(${guild.owner.user.id})\``, true)
      .addField('Member Count', guild.members.cache.size, true)
      .addField('\u200b', '\u200b', true)
      .addField('Guild ID', guild.id, true)
      .addField('Created At', moment(guild.createdAt).format("LLL"), true)
    // client.channels.cache.get('A CHANNEL ID IS NEEDED').send(e);
    client.logger.log(`[GUILD JOIN] ${guild.name} (${guild.id}) added the bot. Owner: ${guild.owner.user.tag} (${guild.owner.user.id})`);
  }
};
