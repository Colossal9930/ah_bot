const Event = require('../base/Event');

module.exports = class extends Event {
  constructor (client) {
    super(client, {
      name: 'ready',
      enabled: true,
    });
  }

  async run (client) {

    // Why await here? Because the ready event isn't actually ready, sometimes
    // guild information will come in *after* ready. 1s is plenty, generally,
    // for all of them to be loaded.
    // NOTE: client.wait is added by ./modules/functions.js!
    await client.wait(1000);

    // This loop ensures that client.appInfo always contains up to date data
    // about the app's status. This includes whether the bot is public or not,
    // its description, owner, etc. Used for the dashboard amongs other things.
    client.appInfo = await client.fetchApplication();
    setInterval( async () => {
      client.appInfo = await client.fetchApplication();
    }, 60000);

    function setupInit() {
      // Set the game as the "Watching for tags"
      client.user.setActivity(`Advertising Hub.`, {type: "WATCHING"});
    };
  
    setupInit();
    setInterval(setupInit, 120000);
    
    // Log that we're ready to serve, so we know the bot accepts commands.
    client.logger.log(`${client.user.tag}, ready to serve ${client.users.cache.size} users in ${client.guilds.cache.size} servers.`, "ready")

    // Reboot system.
    if(client.rebootmap.get('wasRebooted')) {
      await client.channels.cache.get(client.rebootmap.get('ChanID')).messages.fetch(client.rebootmap.get('ID')).then(message => {
        const { MessageEmbed } = require('discord.js');
        const em = new MessageEmbed()
          .setColor('GREEN')
          .setDescription("Bot succesfully rebooted");
        message.edit(em);
      });
      client.rebootmap.set('wasRebooted', false);
    }

    //this.client.emit('remindersetup')
  }
};
