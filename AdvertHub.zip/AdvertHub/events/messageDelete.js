'use strict'
const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'messageDelete',
        enabled: true,
      });
    }
  
    async run (client, message) {
      if(message.channel.type == "dm") return;
      let database = client.database.fn.settings.get(message.guild.id);
      if(database) database = client.database.fn.settings.get(message.guild.id).logs;
      let delby = null;
      if (message.guild.members.cache.get(client.user.id).permissions.has('VIEW_AUDIT_LOG')) message.guild.fetchAuditLogs().then(audit => { delby = audit.entries.first().executor; }).catch(console.error);
      let embed = new MessageEmbed();
      
      if (database.logstoggle) {
        if (message.author.bot == false) {
          embed.setTitle('Message Deleted');
          embed.setURL(message.url);
          embed.setColor('RED');
          embed.setAuthor(message.author.tag, message.author.avatarURL());
          embed.setThumbnail(message.author.displayAvatarURL);
          embed.addField('Deleted Text', (message.content.length <= 1024) ? message.content : `${message.content.substring(0, 1020)}...`, true);
          embed.addField('Channel', message.channel, true);
          embed.addField('Message Author', `${message.author} (${message.author.tag})`, true);
          (delby) ? (message.author !== delby) ? embed.addField('Deleted By', delby, true) : '' : '';
          (message.mentions.users.size === 0) ? embed.addField('Mentioned Users', 'None', true) : embed.addField('Mentioned Users', `Mentioned Member Count: ${message.mentions.users.array().length}\nMentioned Users List: \n ${message.mentions.users.array()}`, true);
          embed.setTimestamp();
          if(!isNaN(database.logsid) && message.guild.channels.cache.find(c => c.id == database.logsid)) message.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
        }
      }
    }
}