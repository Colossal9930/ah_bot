const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'channelUpdate',
        enabled: true,
      });
    }
  
    async run (client, oldChannel, newChannel) {
      if(oldChannel.type == "dm") return;
      let database = client.database.fn.settings.get(oldChannel.guild.id).logs;
      let embed = new MessageEmbed();
      embed.setColor('#20fc3a');
      embed.setFooter(`ID: ${newChannel.id}`);
      embed.setTimestamp();
      if (database.logstoggle) {
        if (oldChannel != newChannel) {
          if(oldChannel.type == "voice") {
            embed.setTitle(`Voice Channel \`${oldChannel.name}\` Updated`);
            embed.addField('Name',  newChannel.name, true);
            embed.addField('Bitrate', newChannel.bitrate, true);
            embed.addField('User Limit', (newChannel.userLimit == 0) ? "Unlimited" : newChannel.userLimit, true);
            embed.addField('Category', newChannel.parent.name, true);
            embed.addField('Position', newChannel.position, true);
          }else if(oldChannel.type == "text"){
            embed.setTitle(`Text Channel ${oldChannel.name} Updated`);
            embed.addField('Name', newChannel.name, true);
            embed.addField('Topic', newChannel.topic ? newChannel.topic : 'Empty Topic', true);
            embed.addField('Is NSFW?', (newChannel.nsfw) ? "Yes" : "No", true);
            embed.addField('Category', newChannel.parent.name, true);
            embed.addField('Position', newChannel.position, true);
          }else if(oldChannel.type == "category"){
            embed.setTitle(`Category ${oldChannel.name} Updated`);
            embed.addField('Name', newChannel.name, true);
            embed.addField('Position', newChannel.position, true);
          }
          if(!isNaN(database.logsid) && oldChannel.guild.channels.cache.find(c => c.id == database.logsid)) oldChannel.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
        }
      }
    }
}