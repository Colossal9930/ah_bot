const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'roleUpdate',
        enabled: true,
      });
    }
  
    async run (client, oldRole, newRole) {
      let database = client.database.fn.settings.get(oldRole.guild.id);
      if(database) database = client.database.fn.settings.get(oldRole.guild.id).logs;
      let embed = new MessageEmbed();
      
      if (database.logstoggle) {
        if (newRole.id != newRole.guild.id) {
          if (oldRole.name != newRole.name || oldRole.hexColor != newRole.hexColor) {
            embed.setTitle(`Role "${oldRole.name}" Updated`);
            embed.setColor(newRole.hexColor);
            embed.addField('Name', newRole.name, true);
            embed.addField('Color', newRole.hexColor, true);
            embed.setFooter(`ID: ${newRole.id}`);
            embed.setTimestamp();
            if(!isNaN(database.logsid) && oldRole.guild.channels.cache.find(c => c.id == database.logsid)) oldRole.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
          }
        }
      }
    }
}