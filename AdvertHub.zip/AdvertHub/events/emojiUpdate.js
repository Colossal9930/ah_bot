const { MessageEmbed } = require('discord.js')
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'emojiUpdate',
        enabled: true,
      });
    }
  
    async run (client, oldEmoji, newEmoji) {
      let database = client.database.fn.settings.get(oldEmoji.guild.id);
      if (database) database = client.database.fn.settings.get(oldEmoji.guild.id).logs;
      let embed = new MessageEmbed()

      if (database.logstoggle) {
        embed.setTitle(`Emoji \`${oldEmoji.name}\` Updated`);
        embed.setColor('#20fc3a');
        embed.setThumbnail(oldEmoji.url);
        embed.addField('Name', newEmoji.name, true);
        embed.addField('Identifier', newEmoji.identifier, true);
        //embed.addField('Is Animated?', newEmoji.animated, true);
        embed.setFooter(`ID: ${newEmoji.id}`);
        embed.setTimestamp();
        if(!isNaN(database.logsid) && oldEmoji.guild.channels.cache.find(c => c.id == database.logsid)) oldEmoji.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
      }
    }
}