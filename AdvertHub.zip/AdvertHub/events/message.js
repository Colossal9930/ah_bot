// The MESSAGE event runs anytime a message is received
// Note that due to the binding of client to every event, every event
// goes `client, other, args` when this function is run.
const { REGEX: { REGEX }, DEFAULTS } = require('../modules/constants.js');
const { escapeRegExp } = require('../modules/Utils');
const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');
const permLevels = require('../base/Level');

module.exports = class extends Event {
  constructor (client) {
    super(client, {
      name: 'message',
      enabled: true,
    });
  }

  async run (client, message) {
    // Get useful properties from the message object
    const { author, channel, content, guild } = message;
    const database = client.database;

    // Ignore other bots
    if (author.bot) return;

    // Cancel any attempt to execute commands if the bot cannot respond to the user.
    if (guild && !channel.permissionsFor(message.guild.me).missing("SEND_MESSAGES")) return;

    // Create guild data if it doesnt exist.
    if (guild && (database.fn.settings.get(guild.id) == null || database.fn.settings.get(guild.id).general == null)) database.fn.settings.copyDefaults(guild.id);

    // Ensure guild data.
    if(message.channel.type != "dm") database.fn.settings.ensure(guild.id);

    // Grab the settings for this server from the database
    // If there is no guild, get default conf (DMs)
    const settings = guild ? database.fn.settings.get(guild.id) : DEFAULTS;

    // For ease of use in commands and functions, we'll attach the settings
    // to the message object, so `message.settings` is accessible.
    message.settings = settings;
    
    // Prefix related tasks
    const prefix = settings.general.prefix;
    const fixedPrefix = escapeRegExp(prefix);
    const fixedUsername = escapeRegExp(client.user.username);

    const PrefixRegex = new RegExp(`^(<@!?${client.user.id}>|${fixedPrefix}|${fixedUsername})`, 'i', '(\s+)?');

    let usedPrefix = content.match(PrefixRegex);
    usedPrefix = usedPrefix && usedPrefix.length && usedPrefix[0];

    // Mention related tasks
    const MentionRegex = new RegExp(`^(<@!?${client.user.id}>)`);
    const mentioned = MentionRegex.test(content);
    const helpPrefix = `👋 Hai! This guild's prefix is \`${prefix}\``;

    if(!usedPrefix) return; // Exit if its not using a prefix
    // Here we separate our "command" name, and our "arguments" for the command.
    // e.g. if we have the message "+say Is this the real life?" , we'll get the following:
    // command = say
    // args = ["Is", "this", "the", "real", "life?"]
    const args = message.content.slice(usedPrefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();

    // If the member on a guild is invisible or not cached, fetch them.
    if (message.guild && !message.member) await message.guild.members.fetch(message.author);

    // Get the user or member's permission level from the elevation
    const level = client.permLevel(message);

    // Check whether the command, or alias, exist in the collections defined
    // in app.js.
    const cmd = client.commands.get(command) || client.commands.get(client.aliases.get(command));

    // Check if command exists.
    if (!cmd && mentioned) return message.channel.send(helpPrefix);
    if (!cmd) return;

    // Some commands may not be useable in DMs. This check prevents those commands from running
    // and return a friendly error message.
    if (cmd && !message.guild && cmd.conf.guildOnly) return message.channel.send("This command is unavailable via private message. Please run this command in a guild.");

    if (level < this.client.levelCache[cmd.conf.permLevel]) {
      const e = new MessageEmbed()
        .setTitle('Invalid Permissions')
        .setColor('RED')
        .setDescription(`You have to be ${(client.levelCache[cmd.conf.permLevel] == 4) ? 'the' : 'a'} **${cmd.conf.permLevel}** to use this command.`);
      message.channel.send(e);
      client.logger.log(`${permLevels.find(l => l.level === level).name} ${message.author.username} (${message.author.id}) ran unauthorized command ${cmd.help.name} ${args.join(' ')}`, "unauthorized");
      return;
    }
      
    // To simplify message arguments, the author's level is now put on level (not member, so it is supported in DMs)
    // The "level" command module argument will be deprecated in the future.
    message.author.permLevel = level;

    message.flags = [];
    while (args[0] &&args[0][0] === "-") {
      message.flags.push(args.shift().slice(1));
    }
    
    // If the command exists, **AND** the user has permission, run it.
    //this.client.logger.log(`${this.client.config.permLevels.find(l => l.level === level).name} ${message.author.username} (${message.author.id}) ran command ${cmd.help.name} ${args.join(' ')}`, "cmd");

    cmd.run(client, message, args, level, database, MessageEmbed);
  }
};