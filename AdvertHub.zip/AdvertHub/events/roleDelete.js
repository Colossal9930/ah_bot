const { MessageEmbed } = require('discord.js');
const Event = require('../base/Event');

module.exports = class extends Event {
    constructor (client) {
      super(client, {
        name: 'roleDelete',
        enabled: true,
      });
    }
  
    async run (client, role) {
      let database = client.database.fn.settings.get(role.guild.id);
      if(database) database = client.database.fn.settings.get(role.guild.id).logs;
      let embed = new MessageEmbed();

      if (database.logstoggle) {
        embed.setTitle('Role Deleted');
        embed.setColor('RED');
        embed.addField('Name', role.name, true);
        embed.addField('Managed', role.managed, true);
        embed.addField('Position', role.position, true);
        embed.setFooter(`ID: ${role.id}`);
        embed.setTimestamp();
        if(!isNaN(database.logsid) && role.guild.channels.cache.find(c => c.id == database.logsid)) role.guild.channels.cache.find(c => c.id == database.logsid).send(embed);
      }
    }
}