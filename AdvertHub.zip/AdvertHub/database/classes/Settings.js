const DEFAULTS = {
  general: {
      prefix: 'ah?',
      modrole: 'Moderator',
      adminrole: 'Administator',
      language: 'en-US',
    },
    welcome: {
      welcomeid: null,
      welcomemsg: `Welcome {{tag}} to {{guild}}, please read over the rules and have fun.`,
      welcomecolor: 'BLUE',
      welcometoggle: false,
    },
    leave: {
      leaveid:  null,
      leavemsg: `Bye {{user}}. All good things come to an end`,
      leavecolor: 'BLUE',
      leavetoggle: false,
    },
    automod: {
      antilinks: false,
      antispam: false,
      levelsystem: false,
    },
    logs: {
      logsid: null,
      logstoggle: false,
    },
}



class Settings {
  constructor(client, database) {
    this.client = client;
    this.database = database;
  }

  /**
   * Gets the stored data of a guild
   * @param {String} guildID
   */
  get(guildID) {
    return this.database.settings.get(guildID);
  }

  /**
   * Sets the stored data of a guild
   * @param {String} guildID
   * @param {*} data
   */
  set(guildID, data) {
    const { 
      prefix, modrole, adminrole, language, 
      welcomeid, welcomemsg, welcomecolor, welcometoggle,
      leaveid, leavemsg, leavecolor, leavetoggle, 
      antilinks, antispam, levelsystem,
      logstoggle, logsid,
      // add more settings here
    } = data;

    const result = {
      general: {
        prefix: prefix || 'ah?',
        modrole: modrole || 'Moderator',
        adminrole: adminrole || 'Administator',
        language: language || 'en-US',
      },
      welcome: {
        welcomeid: welcomeid || null,
        welcomemsg: welcomemsg || `Welcome {{tag}} to {{guild}}, please read over the rules and have fun.`,
        welcomecolor: welcomecolor || 'BLUE',
        welcometoggle: welcometoggle || false,
      },
      leave: {
        leaveid: leaveid || null,
        leavemsg: leavemsg || `Bye {{user}}. All good things come to an end.`,
        leavecolor: leavecolor || 'BLUE',
        leavetoggle: leavetoggle || false,
      },
      automod: {
        antilinks: antilinks || false,
        antispam: antispam || false,
        levelsystem: levelsystem || false,
      },
      logs: {
        logstoggle: logstoggle || false,
        logsid: logsid || null,
      },
    };
    return this.database.settings.set(guildID, result);
  }

  /**
   * Deletes the data of a guild
   * @param {String} guildID
   */
  delete(guildID) {
    return this.database.settings.delete(guildID);
  }

  update(guildID, { key, value }) {
    let oldData = this.database.settings.get(guildID);
    for (const i in oldData) {
      if (key in oldData[i]) {
        oldData[i][key] = value;
        return this.database.settings.set(guildID, oldData);
      }
    }
    return new Error('Key not found');
  }

  ensure(guildID) {
    if(!this.database.settings.get(guildID).general) this.database.settings.set(guildID, { prefix: 'ah?', modrole: 'Moderator', adminrole: 'Administator', language: 'en-US', }, 'general');
    if(!this.database.settings.get(guildID).welcome) this.database.settings.set(guildID, { welcomeid: null, welcomemsg: `Welcome {{tag}} to {{guild}}, please read over the rules and have fun.`, welcomecolor: 'BLUE', welcometoggle: false, }, 'welcome');
    if(!this.database.settings.get(guildID).leave) this.database.settings.set(guildID, { leaveid: null, leavemsg: `Bye {{user}}. All good things come to an end.`, leavecolor: 'BLUE', leavetoggle: false, }, 'leave');
    if(!this.database.settings.get(guildID).automod) this.database.settings.set(guildID, { antilinks: false, antispam: false, levelsystem: false }, 'automod');
    if(!this.database.settings.get(guildID).logs) this.database.settings.set(guildID, { logstoggle: false, logsid: null, }, 'logs');
    return false;
  }

  /**
   * Copy Default Settings.
   * @param {String} guildID 
   */
  copyDefaults(guildID) {
    return this.database.settings.set(guildID, DEFAULTS);
  }
}

module.exports = Settings;
