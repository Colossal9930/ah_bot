module.exports = {
  // classes
  Settings: require('./Settings.js'),
};
