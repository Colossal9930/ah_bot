'use strict';
const { version } = require("discord.js");

if (Number(process.version.slice(1).split(".")[0]) < 8) throw new Error("Node 8.0.0 or higher is required. Update Node on your system.");
if (Number(version.slice(0, 2).split('.')[0]) < 12) throw new Error("Discord.JS 12 or higher is required. Update discord.js");

// Load up the Client
const { CLIENT_OPTIONS } = require('./modules/constants.js');
const TechyClient = require('./base/TechyClass.js');
const client = new TechyClient(CLIENT_OPTIONS);
const permLevels = require('./base/Level');

client.login(client.config.token);

client.levelCache = {};

for (let i = 0; i < permLevels.length; i++) {
  const thisLevel = permLevels[i];
  client.levelCache[thisLevel.name] = thisLevel.level;
}

client.on("disconnect", () => client.logger.log("Bot is disconnecting...", "warn"))
  .on("reconnecting", () => client.logger.log("Bot reconnecting...", "log"))
  .on("error", e => client.logger.log(e, "error"))
  .on("warn", info => client.logger.log(info, "warn"));

/* MISCELANEOUS NON-CRITICAL FUNCTIONS */

// EXTENDING NATIVE TYPES IS BAD PRACTICE. Why? Because if JavaScript adds this
// later, this conflicts with native code. Also, if some other lib you use does
// this, a conflict also occurs. KNOWING THIS however, the following methods
// are, we feel, very useful in code. So let's just Carpe Diem.

// <String>.isBoolean() returns a boolean value such as:
// "enabled".isBoolean() returns true
String.prototype.isBoolean = function(){
  if(this == "true" || this == "enabled" || this == "yes"){
    return true;
  }else if(this == "false" || this == "disabled" || this == "no"){
    return false;
  }else{
    return this;
  }
}

// <String>.toPropercase() returns a proper-cased string such as: 
// "Mary had a little lamb".toProperCase() returns "Mary Had A Little Lamb"
String.prototype.toProperCase = function () {
  return this.replace(/([^\W_]+[^\s-]*) */g, function (txt) {return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
};
// <Array>.random() returns a single random element from an array
// [1, 2, 3, 4, 5].random() can return 1, 2, 3, 4 or 5.
Array.prototype.random = function () {
  return this[Math.floor(Math.random() * this.length)];
};

// These 2 process methods will catch exceptions and give *more details* about the error and stack trace.
process.on("uncaughtException", (err) => {
  const errorMsg = err.stack.replace(new RegExp(`${__dirname}/`, "g"), "./");
  console.error("Uncaught Exception: ", errorMsg);
  // Always best practice to let the code crash on uncaught exceptions. 
  // Because you should be catching them anyway.
  process.exit(1);
});

process.on("unhandledRejection", err => {
  console.error("Uncaught Promise Error: ", err);
});